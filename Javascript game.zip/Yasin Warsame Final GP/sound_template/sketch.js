/*

- Copy your game project code into this file
- for the p5.Sound library look here https://p5js.org/reference/#/libraries/p5.sound
- for finding cool sounds perhaps look here
https://freesound.org/


*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var scrollPos;
var gameChar_world_x;

var isLeft;
var isRight;
var isFalling;
var isPlummeting;

var platforms;

var game_score;

var castle;

var lives;

var enemies;


var jumpSound;
var castleSound
var enemySound

function preload()
{
    soundFormats('mp3','wav');
    
    //load your sounds here
    jumpSound = loadSound('assets/jump.wav');
    jumpSound.setVolume(0.1);
    
    enemySound = loadSound('assets/enemy.mp3');
    enemySound.setVolume(0.1);
    
    castleSound = loadSound('assets/castle.mp3');
    castleSound.setVolume(0.1);
}


function setup()
{
	createCanvas(1024, 576);
    
    floorPos_y = height * 3/4;
    
    startGame();
    
    lives = 3;
}


function draw()
{
	background(100, 155, 255); // fill the sky blue

	noStroke();
	fill(0,155,0);
	rect(0, floorPos_y, width, height/4); // draw some green ground
    push();
    translate(scrollPos, 0);

 
//	// Draw clouds.
    drawClouds();

//	// Draw mountains.
    
    drawMountains();
    // Draw trees.

    drawTrees();
//	// Draw canyons.
    for(var i = 0; i < canyon.length; i++)
            {
                drawCanyon(canyon[i]);
                checkCanyon(canyon[i]);
            }


	// Draw collectable items.
     for (var i = 0; i < collectable.length; i++)
         {
             if(!collectable[i].isfound)
             {
                 drawCollectable(collectable[i]);
                 checkCollectable(collectable[i]);
             }
         }
    
    if(!checkCastle.isReached)
        {
            renderCastle(castle);
            checkCastle(castle);
        }
//    renderCastle(castle);
    for (var i = 0; i < enemies.length; i++)
        {
            enemies[i].update();
            enemies[i].draw();
            
            if(enemies[i].isContact(gameChar_world_x, gameChar_y))
                {
                    enemySound.play();
                    startGame();
                    break;
                }
        }
        
    for (var i = 0; i < platforms.length; i++)
        {
            platforms[i].draw();
        }
    
    
    
 pop();
    
    

	// Draw game character.
	
	drawGameChar();
    
    
    
    textSize(14);
    text("score: " + game_score, 20, 40);
    text("lives: " + lives, 20,60);
    
    
    if(castle.isReached)
        {
            textSize(30);
            text("level complete! refresh page to continue", 200, 200)
        }
    else if(lives < 0)
    {
        textSize(30);
        text("You failed! Refresh to restart", 300,200)
    }

    if(gameChar_y > height)
    {
        if(lives >= 0)
        startGame();
    }
         
    
    

	// Logic to make the game character move or the background scroll.
	if(isLeft)
	{
		if(gameChar_x > width * 0.2)
		{
			gameChar_x -= 7;
		}
		else
		{
			scrollPos += 7;
		}
	}

	if(isRight)
	{
		if(gameChar_x < width * 0.8)
		{
			gameChar_x  += 7;
		}
		else
		{
			scrollPos -= 7; // negative for moving against the background
		}
	}

    // Logic to make the game character move up or down.
    
    if(gameChar_y < floorPos_y)
        {
            
            var isContact = false;
            
            for( var i =0; i< platforms.length; i++)
                {
                   if(platforms[i].checkContact(gameChar_world_x,gameChar_y) == true)
                   {
                    isContact = true;
                       break;
                   }
                }
            if(isContact == false)
                {
                    gameChar_y+=2;
                    isFalling = true;
                }
            else
                {
                    isFalling = false;
                }
        }
    else
    {
        isFalling = false;
    }
            
    if(isPlummeting)
        {
            gameChar_y += 3;
        }
   

	// Update real position of gameChar for collision detection.
	gameChar_world_x = gameChar_x - scrollPos;
}


// ---------------------
// Key control functions
// ---------------------

function keyPressed(){

	console.log("press" + keyCode);
	console.log("press" + key);
    
    if(!isPlummeting)
        {
    if(keyCode == 65) // key a
        {
            
            isLeft = true;
        }
    
    if(keyCode == 68) // key d
        {
                    isRight = true;
            
        }
    
    if(keyCode == 87 && gameChar_y == floorPos_y ) // key w
        {
            isFalling = true;
            gameChar_y -= 100;
            jumpSound.play();
        }
        }
    

}

function keyReleased()
{

	console.log("release" + keyCode);
	console.log("release" + key);
    
 
    
     if(keyCode == 65)
        {
            isLeft = false;
        }
    
    if(keyCode == 68)
        {
            isRight = false;
        }
    
     
    if(keyCode == 87 && gameChar_y == floorPos_y ) 
        {
            isFalling = false;
        }
        
    

}


// ------------------------------
// Game character render function
// ------------------------------


// Function to draw the game character.

function drawGameChar()
{
    if(isLeft && isFalling)
	{
		// add your jumping-left code
    fill(0,0, 255);
    rect(gameChar_x - 15,gameChar_y - 45,15,20);
    fill(128,128,128);
    ellipse(gameChar_x - 10, gameChar_y - 55,10,20);
    fill(0,0,0);
    rect(gameChar_x - 20, gameChar_y - 25, 10, 10);
    fill(0,0,0);
    rect(gameChar_x - 10, gameChar_y - 25 , 10, 10);

	}
	else if(isRight && isFalling)
	{
		// add your jumping-right code
    fill(0,0, 255);
    rect(gameChar_x - 20,gameChar_y - 45,15,20);
    fill(128,128,128);
    ellipse(gameChar_x - 10, gameChar_y - 55,10,20);
    fill(0,0,0);
    rect(gameChar_x - 20, gameChar_y - 25, 10, 10);
    fill(0,0,0);
    rect(gameChar_x - 10, gameChar_y - 25 , 10, 10);


	}
	else if(isLeft)
	{
		// add your walking left code
    fill(0,0, 255);
    rect(gameChar_x - 15,gameChar_y - 45,15,40);
    fill(128,128,128);
    ellipse(gameChar_x - 10, gameChar_y - 55,20,20);
    fill(0,0,0);
    rect(gameChar_x - 20, gameChar_y - 10, 10, 10);
    fill(0,0,0);
    rect(gameChar_x - 10, gameChar_y - 10 , 10, 10);

	}
	else if(isRight)
	{

    fill(0,0, 255);
    rect(gameChar_x - 20,gameChar_y - 45,15,40);
    fill(128,128,128);
    ellipse(gameChar_x - 10, gameChar_y - 55,20,20);
    fill(0,0,0);
    rect(gameChar_x - 20, gameChar_y - 10, 10, 10);
    fill(0,0,0);
    rect(gameChar_x - 10, gameChar_y - 10 , 10, 10);

	}
	
    else if(isFalling || isPlummeting)
	{
		// add your jumping facing forwards code
    fill(0,0, 255);
    rect(gameChar_x - 15,gameChar_y - 45,20,30);
    fill(128,128,128);
    ellipse(gameChar_x - 5, gameChar_y - 55,20,20);
    fill(0,0,0);
    rect(gameChar_x - 16, gameChar_y - 20, 10, 10);
    fill(0,0,0);
    rect(gameChar_x, gameChar_y - 20 , 10, 10);
	}
      else if (isPlummeting)
	{
		// add your jumping facing forwards code
    fill(0,0, 255);
    rect(gameChar_x - 15,gameChar_y - 45,20,30);
    fill(128,128,128);
    ellipse(gameChar_x - 5, gameChar_y - 55,20,20);
    fill(0,0,0);
    rect(gameChar_x - 16, gameChar_y - 20, 10, 10);
    fill(0,0,0);
    rect(gameChar_x, gameChar_y - 20 , 10, 10);
	}
	else
	{
		// add your standing front facing code
    fill(0,0, 255);
    rect(gameChar_x - 15,gameChar_y - 45,20,40);
    fill(128,128,128);
    ellipse(gameChar_x - 5, gameChar_y - 55,20,20);
    fill(0,0,0);
    rect(gameChar_x - 16, gameChar_y - 10, 10, 10);
    fill(0,0,0);
    rect(gameChar_x, gameChar_y - 10, 10, 10);
    

	}

    
    
    // draw game character
}

// ---------------------------
// Background render functions
// ---------------------------

// Function to draw cloud objects.

// Function to draw mountains objects.

// Function to draw trees objects.



// ---------------------------------
// Canyon render and check functions
// ---------------------------------

// Function to draw canyon objects.

function drawCanyon(t_canyon)
{
    fill(139,69,19);
    stroke(0);
    rect(t_canyon.pos_x, floorPos_y, t_canyon.width,200);
}

// Function to check character is over a canyon.

function checkCanyon(t_canyon)
{
    if(gameChar_world_x > t_canyon.pos_x && gameChar_world_x < t_canyon.pos_x + t_canyon.width && gameChar_y >= floorPos_y)
        {
            isPlummeting = true;
//            lives --;
        }
}

// ----------------------------------
// Collectable items render and check functions
// ----------------------------------

// Function to draw collectable objects.

function drawCollectable(t_collectable)
{
        {
            noFill();
            strokeWeight(6);
            stroke(220,185,0);
            ellipse(t_collectable.pos_x, floorPos_y - 20, t_collectable.size, t_collectable.size);
            fill(230,230,250);
            
            noStroke();
        }
}

// Function to check character has collected an item.

function checkCollectable(t_collectable)
{
    var Dis = dist(gameChar_world_x, gameChar_y, t_collectable.pos_x, t_collectable.pos_y);
    
    if(Dis < 40 )
        {
            t_collectable.isfound = true
            game_score +=1;
        
        };
    
        if(t_collectable.isfound == false)
        {
            noFill();
            strokeWeight(6);
            stroke(220,185,0);
            ellipse(t_collectable.pos_x, t_collectable.pos_y-20, t_collectable.size, t_collectable.size);
            fill(230,230,250);


            noStroke();
        };
}


function drawClouds()
{
        for(var i = 0; i < clouds.length; i++)
        {
            noStroke();
            fill(255,255,255);
            ellipse(200 + i * 400,80 + i,200,100);
             ellipse(30 + i * 200,80 + i,50,50);
        }
}

function drawMountains()
{
         for( var i = 0; i < mountains.length; i++)
         {
            noStroke();
            fill(105,105,105);
             triangle(mountains[i].pos_x - mountains[i].height/2, floorPos_y, mountains[i].pos_x, floorPos_y-mountains[i].height, mountains[i].pos_x + mountains[i].height/2, floorPos_y);
         }
}

function drawTrees()
{
     for(var i = 0; i < trees_x.length; i++ )
        {
                fill(100,50,0);
                rect(trees_x[i] -25,-150 + 432,50,150);
                fill(0,100,0);
                triangle(
                    trees_x[i]-75,-150 + 432,
                    trees_x[i],-300 + 432,
                    trees_x[i]+75,-150 + 432);

                triangle(
                    trees_x[i]-100,-75+432,
                    trees_x[i],-225 + 432,
                    trees_x[i]+ 100,-75 + 432);
        }   
}
    
function createPlatform(x,y,length)
{
    
    var p = {
                x: x,
                y: y,
                length: length,
                draw: function()    
                {
                    
                
                    fill(255,255,0);
                    stroke(0);
                    rect(this.x,this.y,this.length, 20);
                },    
                
                checkContact: function(gc_x, gc_y)
                {
                    //checks whether theres contact or not with the platform
                    if(gc_x> this.x && gc_x<this.x + this.length)
                    {   
                        var d = this.y - gc_y;
                        if(d >= 0 && d < 10)
                        {
                            
                            return true;
                            
                        }
                    }
                    
                    return false;
                    
                }
            }
    return p;
    
}

function renderCastle(t_castle)
            {
                push();
    
                fill(169,169,169)
                rect(5200,232,200,200)
                fill(255,255,255)
                rect(5220,272,20,20)
                rect(5280,272,20,20)
                rect(5350,272,20,20)
                fill(0)
                rect(5200,192,40,40)
                rect(5280,192,40,40)
                rect(5350,192,40,40)
                fill(139,69,19)
                rect(5270,332,80,100)
                pop();
                
            
    if(t_castle.isReached)
        {
                push();
    
                fill(169,169,169)
                rect(5200,232,200,200)
                fill(255,255,255)
                rect(5220,272,20,20)
                rect(5280,272,20,20)
                rect(5350,272,20,20)
                fill(0)
                rect(5200,192,40,40)
                rect(5280,192,40,40)
                rect(5350,192,40,40)
                fill(0)
                rect(5270,332,80,100)
                pop();
                
                castleSound.play();
            
        }
}

function checkCastle(t_castle)
{
    if(dist(gameChar_world_x, 0, castle.x_pos, 0) < 10)
        {
            t_castle.isReached = true;
        }
}

function Enemy(x,y,range)
{
    this.x = x;
    this.y = y;
    this.range = range;
    this.current_x = x;
    this.incr = 1;
    
    this.draw = function()
    {
        push();
        fill(255,0,0);
        ellipse(this.current_x,this.y - 25, 50);
        fill(0);
        ellipse(this.current_x - 5, this.y - 25, 5);
        ellipse(this.current_x + 5, this.y - 25, 5);
        stroke(0)
        strokeWeight(2)
        line(this.current_x - 15, this.y - 35, this.current_x - 5, this.y - 30);
        line(this.current_x + 15, this.y -35, this.current_x + 5, this.y - 30);
        
        pop();
        
    }
    this.update = function()
    {
        this.current_x += this.incr;
        
        if(this.current_x < this.x)
            {
                this.incr =1;
            }
        else if(this.current_x > this.x + this.range)
            {
                this.incr -=1;
            }
    }
    
    this.isContact = function(gc_x, gc_y)
    {
        //returns true if contact is there
        var d = dist(gc_x,gc_y, this.current_x, this.y)
        if(d < 25)
            
        {
            return true;
        }
        return false;
    }
    
}


function startGame()
{
    gameChar_x = width/2;
	gameChar_y = floorPos_y;

	// Variable to control the background scrolling.
	scrollPos = 0;

	// Variable to store the real position of the gameChar in the game
	// world. Needed for collision detection.
	gameChar_world_x = gameChar_x - scrollPos;

	// Boolean variables to control the movement of the game character.
	isLeft = false;
	isRight = false;
	isFalling = false;
	isPlummeting = false;

	// Initialise arrays of scenery objects.
    mountains = [
                 {pos_x: 200, height: 200},
                 {pos_x: 500, height: 200},
                 {pos_x: 900, height: 200},
                 {pos_x: 1200, height: 200},
                 {pos_x: 1300, height: 200},
                 {pos_x: 1600, height: 200},
                 {pos_x: 1900, height: 200},
                 {pos_x: 2100, height: 200},
                 {pos_x: 2300, height: 200},
                 {pos_x: 2600, height: 200},
                 {pos_x: 2800, height: 200},
                 {pos_x: 3000, height: 200},
                 {pos_x: 3400, height: 200},
                 {pos_x: 3600, height: 200},
                 {pos_x: 3800, height: 200},
                 {pos_x: 4200, height: 200},
                 
                ];
    trees_x = [100,400,600,900,1200,1500,1900,2200,2400,2600,2800,3000,3400,3700,4000,4300,4800];
    clouds = 
             [
                {pos_x: 30, pos_y: 80},
                {pos_x: 60, pos_y: 100},
                {pos_x: 100, pos_y: 130},
                {pos_x: 300, pos_y: 100},
                {pos_x: 400, pos_y: 100},
                {pos_x: 600, pos_y: 100},
                {pos_x: 1000, pos_y: 100},
                {pos_x: 1300, pos_y: 100},
                {pos_x: 1500, pos_y: 100},
                {pos_x: 1800, pos_y: 100},
                {pos_x: 2000, pos_y: 100},
                {pos_x: 2300, pos_y: 100},
             ];
    canyon =
            [   {pos_x: 100, width: 180},
                {pos_x: 700, width: 180},
                {pos_x: 1000, width: 280},
                {pos_x: 1800, width: 180},
                {pos_x: 1800, width: 180},
                {pos_x: 2200, width: 180},
                {pos_x: 2600, width: 180},
                {pos_x: 3000, width: 180},
                {pos_x: 3400, width: 180},
                {pos_x: 3700, width: 180},
                {pos_x: 4000, width: 180},
                {pos_x: 4400, width: 180},
            ];
    collectable = [
                      {pos_x: -100, pos_y: floorPos_y, size: 40},
                      {pos_x: 300, pos_y: floorPos_y, size: 40},
                      {pos_x: 900, pos_y: floorPos_y, size: 40},
                      {pos_x: 1350, pos_y: floorPos_y, size: 40},
                      {pos_x: 1700, pos_y: floorPos_y, size: 40},
                      {pos_x: 2000, pos_y: floorPos_y, size: 40},
                      {pos_x: 2500, pos_y: floorPos_y, size: 40},
                      {pos_x: 2900, pos_y: floorPos_y, size: 40},
                      {pos_x: 3300, pos_y: floorPos_y, size: 40},
                      {pos_x: 3700, pos_y: floorPos_y, size: 40},
                      {pos_x: 4800, pos_y: floorPos_y, size: 80},
                  ];
    platforms = [];
    
    platforms.push(createPlatform(0,floorPos_y - 90,100));
    platforms.push(createPlatform(1100,floorPos_y - 60,100));
    platforms.push(createPlatform(1100,floorPos_y - 60,100));
    platforms.push(createPlatform(1100,floorPos_y - 60,100));
    
    game_score = 0;
    
    castle = { x_pos: 5200, isReached: false, height: 300};
    
    lives -= 1;
    
    enemies = [];
    
    enemies.push(new Enemy(0, floorPos_y,100));
    enemies.push(new Enemy(2400, floorPos_y,100));
    enemies.push(new Enemy(3400, floorPos_y,100));
    enemies.push(new Enemy(5000, floorPos_y,100));
    
    
}